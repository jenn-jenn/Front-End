function equal(a, b) {
	return a === b;
}